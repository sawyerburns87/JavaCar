import java.awt.*;
import java.util.ArrayList;

public class Flag{
    int flagIndex = 0;
    int flagScore = 10;
    ArrayList<Force> collides = new ArrayList<Force>();
    Force thePos;

    Flag(Force pos, int dia, int newScore){
        for(int x = (int)(pos.x - dia/2); x < (int)(pos.x + dia/2); x++){
            for(int y = (int)(pos.y - dia/2); y < (int)(pos.y + dia/2); y++){
                collides.add(new Force(x, y));
            }
        }
        thePos = pos;
        flagScore = newScore;
    }

    public int getScore(){
        return flagScore;
    }

    public ArrayList<Force> getCollides(){
        return collides;
    }

    public Force getPos(){
        return thePos;
    }

    public void paint(Graphics g){
        g.setColor(Color.GREEN);
        g.drawRect((int)thePos.x, (int)thePos.y, 5, 5);
        //ArrayList<Force> cols = collides;
        //for(int a = 0; a < cols.size(); a++){
        //    g.drawLine((int)cols.get(a).x, (int)cols.get(a).y, (int)cols.get(a).x, (int)cols.get(a).y);
        //}
    }
}