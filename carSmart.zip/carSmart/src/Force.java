public class Force {
    double x;
    double y;

    Force(double newX, double newY){
        x = newX;
        y = newY;
    }

    Force(){
        x = 0;
        y = 0;
    }

    public Force add(Force other){
        x += other.x;
        y += other.y;
        return this;
    }
    public Force sub(Force other){
        x -= other.x;
        y -= other.y;
        return this;
    }
    public Force scl(double other){
        x *= other;
        y *= other;
        return this;
    }
    public Force scl(double otherx, double othery){
        x *= otherx;
        y *= othery;
        return this;
    }

    public double getDist(Force other){
        return this.tempSub(other).getMag();
    }

    public Force getNorm(){
        return new Force((1/getMag()) * x, (1/getMag()) * y);
    }

    public Force tempSub(Force other){
        return new Force(x - other.x, y - other.y);
    }
    public Force tempAdd(Force other){
        return new Force(x + other.x, y + other.y);
    }
    public Force tempScl(double other){
        double tempX = other * x;
        double tempY = other * y;
        return new Force(tempX, tempY);
    }

    public double getMag(){
        return Math.sqrt(x * x + y * y);
    }

    public String testString(){
        return (int)(x*10)/10.0 + ", " + (int)(y*10)/10.0;
    }
}
