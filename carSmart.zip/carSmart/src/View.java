import java.awt.*;
import javax.swing.*;

import java.awt.event.KeyListener;
import java.util.ArrayList;

public class View extends JFrame{
    boolean pressed = false;
    JPanel panel;

	View(ArrayList<Car> newBodies){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setPreferredSize(new Dimension(Const.WINWIDTH, Const.WINHEIGHT));

		this.pack();
        this.setVisible(true);
        panel = new StuffShow(newBodies);
	}

	public void addKeys(KeyListener k){
		this.addKeyListener(k);
	}

	public void displayBodies(){
        panel.repaint();
		this.setContentPane(panel);
		this.setVisible(true);
	}

	public class StuffShow extends JPanel {
		private ArrayList<Car> cars;

		StuffShow(ArrayList<Car> bodies){
            cars = new ArrayList<Car>();
			cars = bodies;
		}

		@Override
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			
			// Draw the box
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, Const.WINWIDTH, Const.WINHEIGHT);

			g.setColor(Color.WHITE);
			for(int i = 0; i < Const.theWall.size(); i++){
				Force wallPos = Const.theWall.get(i);
				g.drawRect((int)(wallPos.x - Const.RES/2), (int)(wallPos.y - Const.RES/2), Const.RES, Const.RES);
			}

			for (Car car : cars) {
                car.paint(g);
			}
		}
	}
}