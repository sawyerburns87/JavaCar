public class Driver{
    public static void main(String[] args) {
        Control con = new Control();
    }
}