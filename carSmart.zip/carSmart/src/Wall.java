import java.io.File;
import java.util.ArrayList;
import java.awt.Color;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

public class Wall {
    static ArrayList<Force> wallArrSimple = new ArrayList<Force>();
    BufferedImage wallImg;
    int res;

    Wall(int simple, ArrayList<Flag> flags){
        res = simple;
        try{
        wallImg = ImageIO.read(new File("../img/wall1.jpg"));
        }
        catch(Exception c){
            System.out.println("Cant open file.");
        }

        for(int x = 0; x < wallImg.getWidth(); x++){
            for(int y = 0; y < wallImg.getHeight(); y++){
                if(x % res == 0 && y % res == 0 && x != 0 && y != 0){
                    checkBox(x, y, flags);
                }
            }
        }
        Const.theWall = wallArrSimple;
        System.out.println(wallArrSimple.size());
    }

    public void checkBox(int x, int y, ArrayList<Flag> flags){
        for(int xa = x - res; xa < x; xa++){
            for(int ya = y - res; ya < y; ya++){
                Color color = new Color(wallImg.getRGB(xa, ya), true);
                int red = color.getRed();
                int green = color.getGreen();
                int blue = color.getBlue();
                
                if(green - ((red + blue) / 2) > 10){
                    //flags.add(new Flag(new Force(x - Math.floor(res/2.0),y - Math.floor(res/2.0)), 50, 10));
                }
                if(red < 5 && green < 5 && blue < 5){
                    wallArrSimple.add(new Force(x - Math.floor(res/2.0),y - Math.floor(res/2.0)));
                    return;
                }
            }
        }
    }

    public static double findDist(Force pos, double ang, double curAng){
        double radAng = Math.toRadians(ang + curAng);
        for (double i = 0; i < 500; i=i+0.5) {
            Force newPos = new Force(pos.x + (Math.cos(radAng) * i), pos.y + (Math.sin(radAng) * i));

            for (Force f : wallArrSimple) {
                if(newPos.getDist(f) < (Const.RES/2.0)){
                    return i;
                }
            }
        }
        return 500;
    }

    public static boolean hasSight(Force from, Force toPos){
        double dist = from.getDist(toPos);
        Force toDir = toPos.tempSub(from).getNorm();

        for (double i = 0; i < dist; i += 3) {
            Force newPos = toDir.tempScl(i).tempAdd(from);

            for (Force f : wallArrSimple) {
                if(newPos.getDist(f) < (Const.RES/2.0)){
                    return false;
                }
            }
        }
        return true;
    }
}
