import java.util.ArrayList;
public class Const {
    public static final int WINWIDTH = 1500;
    public static final int WINHEIGHT = 800;
    public static final int FRAMES = 30;
    public static ArrayList<Force> theWall;
    public static final int RES = 13;
}
