public class carBox {
    Force[] boxPos = new Force[7];
    int counter = 0;

    carBox(int x, int y){
        boxPos[0] = new Force(0, 0);
        boxPos[1] = new Force(0, y/2);
        boxPos[2] = new Force(0, -y/2);
        boxPos[3] = new Force(x/2, y/2);
        boxPos[4] = new Force(x/2, -y/2);
        boxPos[5] = new Force(-x/2, y/2);
        boxPos[6] = new Force(-x/2, -y/2);
    }
    public boolean isContact(Force carPos, double ang, Force otherPos, int discrepency){
        for (Force f : boxPos) {
            int rotX = (int)(carPos.x + (f.x * Math.cos(ang)) - (f.y * Math.sin(ang)));
            int rotY = (int)(carPos.y + (f.y * Math.cos(ang)) + (f.x * Math.sin(ang)));
            Force rotPos = new Force(rotX, rotY);
            if(rotPos.getDist(otherPos) < discrepency){
                return true;
            }
        }

        return false;
    }   
}