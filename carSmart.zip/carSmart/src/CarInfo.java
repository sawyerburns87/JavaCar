public class CarInfo {
    int score = 0;
    double speed = .02;
    double maxSpeed = .1;
    final double idleSpeed = 0.95;
    double turnSpeed = 0.07;
    Force boundingBoxSize = new Force(30, 15);
    carBox box = new carBox((int)boundingBoxSize.x, (int)boundingBoxSize.y);
    Force vel;
    double velMag;

    boolean isDead = false;

    Force lastPos;
    Force pos;
    Force startingPos;
    Force facingDir;
    Force movingDir;
    double ang = 0;

    double slideTime1;
    double slideTime2;
    Force slidePos1;
    Force slidePos2;

    CarInfo(Force newPos, Force newLookDir)
    {
        pos = newPos;
        lastPos = new Force(pos.x, pos.y);
        facingDir = newLookDir;

        ang = Math.atan(facingDir.y/facingDir.x);
        movingDir = new Force();
    }
}
