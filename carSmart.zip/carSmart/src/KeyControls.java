import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyControls implements KeyListener{
    Inputs ins;
    Car carCon;
    
    KeyControls(Inputs newIns, Car newCar){
        ins = newIns;
        carCon = newCar;
    }
    public void keyPressed(KeyEvent e){
        if(e.getKeyChar() == 'w' || e.getKeyChar() == 'W'){
            ins.forward = true;
        }
        if(e.getKeyChar() == 'a' || e.getKeyChar() == 'A'){
            ins.left = true;
        }
        if(e.getKeyChar() == 's' || e.getKeyChar() == 'S'){
            ins.back = true;
        }
        if(e.getKeyChar() == 'd' || e.getKeyChar() == 'D'){
            ins.right = true;
        }
        if(e.getKeyCode() == KeyEvent.VK_SHIFT){
            carCon.sliding(true);
        }
    }
    public void keyTyped(KeyEvent e){
        //
    }
    public void keyReleased(KeyEvent e){
        if(e.getKeyChar() == 'w' || e.getKeyChar() == 'W'){
            ins.forward = false;
        }
        if(e.getKeyChar() == 'a' || e.getKeyChar() == 'A'){
            ins.left = false;
        }
        if(e.getKeyChar() == 's' || e.getKeyChar() == 'S'){
            ins.back = false;
        }
        if(e.getKeyChar() == 'd' || e.getKeyChar() == 'D'){
            ins.right = false;
        }
        if(e.getKeyCode() == KeyEvent.VK_SHIFT){
            carCon.sliding(false);
        }
    }
}