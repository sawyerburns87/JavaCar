
public class Bot {
    static Wall theWall;
    Bot(Wall newWall){
        theWall = newWall;
    }

    public static boolean[] getMoves(double[] info){ // info == (0)forwardDist, (1)RightDist, (2)LeftDist
        boolean[] newMoves = new boolean[5]; // moves == (0)Forward, (1)Back, (2)Left, (3)Right, (4)Slide
        double maxSpeed = 18;
        Force lookDir = new Force(info[9], info[10]);
        Force goalPos = new Force(info[6], info[7]);
        Force carPos = new Force(info[3], info[4]);

        maxSpeed -= (1 / (0.065 + (Math.exp(0.02 * ((2*info[0] + info[1] + info[2])/4.0) - 5))));

        if(theWall.hasSight(carPos, goalPos)){
            maxSpeed = turnTo(lookDir, carPos, goalPos, newMoves, maxSpeed, info);
        }
        else{
            newMoves[0] = true;
            if(info[2] > info[1]){
                newMoves[2] = true;
            }
            else if(info[2] < info[1]){
                newMoves[3] = true;
            }
        }
        if(info[8] > maxSpeed){
            newMoves[0] = false;
        }
        System.out.println(maxSpeed);
        return newMoves;
    }

    public static double getDir(Force lookDir, Force curPos, Force goal){
        Force goalDir = goal.tempSub(curPos).getNorm();
        Force correction = goalDir.tempSub(lookDir);

        double detCorWOrig = (lookDir.x * correction.y) - (lookDir.y * correction.x);
        return detCorWOrig;
    }

    public static double turnTo(Force lookDir, Force curPos, Force goal, boolean[] newMoves, double maxSpeed, double[] info){
        newMoves[0] = true;        
        double detCorWOrig = getDir(lookDir, curPos, goal);

        maxSpeed -= Math.abs(detCorWOrig) * 5;
        if(Math.abs(detCorWOrig) > 0.7){
            newMoves[4] = true;
        }

        if(detCorWOrig > 0 && info[3] > 25){
            newMoves[3] = true;
        }
        else if(detCorWOrig < 0 && info[2] > 25){
            newMoves[2] = true;
        }

        return maxSpeed;
    }
}
