
public class Inputs {
    public boolean forward = false;
    public boolean back = false;
    public boolean left = false;
    public boolean right = false;
    public boolean slide = false;

    Inputs(){

    }
    Inputs(boolean a, boolean b,boolean c,boolean d,boolean e){
        forward = a;
        back = b;
        left = c;
        right = d;
        slide = e;
    }

    public double[] getInputArray(){
        double[] arr = {
            forward ? 1 : 0,back ? 1 : 0,right ? 1 : 0,left ? 1 : 0,slide ? 1 : 0
        };
        return arr;
    }

    public void setInputs(boolean[] newInputs){
        if(newInputs[0]){
            forward = true;
        }
        else{
            forward = false;
        }
        if(newInputs[1]){
            back = true;
        }
        else{
            back = false;
        }
        if(newInputs[2]){
            left = true;
        }
        else{
            left = false;
        }
        if(newInputs[3]){
            right = true;
        }
        else{
            right = false;
        }
        if(newInputs[4]){
            slide = true;
        }
        else{
            slide = false;
        }
    }
}
