import java.util.ArrayList;

public class Control{
    private boolean running = true;
    private long nowTimer = 0;
    private long lastTimer = 0;

    private ArrayList<Car> cars;
    private ArrayList<Car> carBots;
    private ArrayList<Flag> flags;
    private View theView;
    private Wall theWall;
    private int PlayersNum = 1;
    private int BotsNum = 1;

    Control(){
        flags = new ArrayList<Flag>();
        theWall = new Wall(Const.RES, flags);
        Bot bot = new Bot(theWall);
        cars = new ArrayList<Car>();
        carBots = new ArrayList<Car>();

        flags.add(new Flag(new Force(70,200), 100, 1500));
        flags.add(new Flag(new Force(150,690), 110, 1500));
        flags.add(new Flag(new Force(1000,555), 130, 1500));
        flags.add(new Flag(new Force(180,400), 90, 1500));
        flags.add(new Flag(new Force(800,250), 130, 1500));
        flags.add(new Flag(new Force(1300,695), 100, 1500));
        flags.add(new Flag(new Force(1270,65), 85, 1500));

        theView = new View(cars);

        
        for(int i = 0; i < BotsNum + PlayersNum; i++){
            if(i < PlayersNum){
                cars.add(new Car(new Force(100 - ((i%5)*15), 100), new Force(0, 1), new AllFlags(flags), true));
                theView.addKeys(cars.get(i).getKeys());
            }
            else{
                cars.add(new Car(new Force(100 - ((i%5)*17), 100), new Force(0, 1), new AllFlags(flags), false));
                carBots.add(cars.get(i));
            }
        }

        while(running){
            nowTimer = System.currentTimeMillis();
            if(nowTimer - lastTimer > 1000.0/Const.FRAMES){
                lastTimer = nowTimer;

                theView.displayBodies();

                for (Car c : cars) {
                    if(!c.cI.isDead){
                        c.move();
                    }
                    else{
                        c.reset();
                    }
                }

                for (Car c : carBots) {
                    double[] info = new double[11];
                    info[0] = theWall.findDist(c.cI.pos, 0, Math.toDegrees(c.cI.ang));
                    info[1] = theWall.findDist(c.cI.pos, 40, Math.toDegrees(c.cI.ang));
                    info[2] = theWall.findDist(c.cI.pos, -40, Math.toDegrees(c.cI.ang));
                    info[3] = c.cI.pos.x;
                    info[4] = c.cI.pos.y;
                    info[5] = c.cI.ang;
                    info[6] = c.flags.getCurFlag().getPos().x;
                    info[7] = c.flags.getCurFlag().getPos().y;
                    info[8] = c.cI.velMag;
                    info[9] = c.cI.facingDir.x;
                    info[10] = c.cI.facingDir.y;
                    
                    boolean[] newMoves = bot.getMoves(info);
                    c.setInputs(newMoves);
                }
            }
        }
    }
}