import javax.swing.*;
import java.awt.*;

import java.awt.event.KeyListener;


public class Car{
    CarInfo cI;
    CarInfo cIS;

    KeyListener k = null;
    private Image img;

    AllFlags flags;
    Inputs ins;

    Car(Force newPos, Force newLookDir, AllFlags newFlags, boolean useControls){
        cI = new CarInfo(newPos, newLookDir);
        cIS = new CarInfo(new Force(newPos.x, newPos.y), new Force(newLookDir.x, newLookDir.y));
        flags = newFlags;
        ins = new Inputs();

        if(useControls){
            k = new KeyControls(ins, this);
        }
        
        img = new ImageIcon("../img/car.png").getImage();
    }

    public void turnRight(){
        cI.ang += cI.turnSpeed * (cI.movingDir.getMag()/7) + .03;
        cI.facingDir.y = Math.sin(cI.ang);
        cI.facingDir.x = Math.cos(cI.ang);
    }
    public void turnLeft(){
        cI.ang -= cI.turnSpeed * (cI.movingDir.getMag()/7) + .03;
        cI.facingDir.y = Math.sin(cI.ang);
        cI.facingDir.x = Math.cos(cI.ang);
    }

    public void goForward(){
        cI.movingDir.add(cI.facingDir.tempScl(((cI.maxSpeed/cI.speed)-1) * cI.speed));
    }
    public void goBack(){
        //movingDir.add(facingDir.tempScl(((maxSpeed/speed)-1) * -speed));
    }

    public void idle(){
        cI.movingDir.scl(cI.idleSpeed);
        if(cI.movingDir.getMag() < 0.2){
            cI.movingDir.scl(0);
        }
    }

    public int getScore(){
        cI.score = 0;
        int dif = (int)cI.lastPos.getDist(flags.getCurFlag().getPos()) - (int)cI.pos.getDist(flags.getCurFlag().getPos());
        cI.lastPos.x = cI.pos.x;
        cI.lastPos.y = cI.pos.y;
        cI.score += dif;
        return cI.score;
    }

    public void sliding(boolean going){
        if(going){
            ins.slide = true;
            cI.turnSpeed = cIS.turnSpeed * 1.6;
            cI.slideTime1 = System.currentTimeMillis();
            cI.slidePos1 = cI.pos;
        }
        else{
            ins.slide = false;
            cI.turnSpeed = cIS.turnSpeed;
            cI.slideTime2 = System.currentTimeMillis();
            cI.slidePos2 = cI.pos;
            if(Math.abs(cI.slideTime2 - cI.slideTime1) > 1000 || cI.slidePos1.getDist(cI.slidePos2) > 100){
                cI.movingDir.add(cI.facingDir.getNorm().scl(7));
            }
        }
    }

    public void checkWall(){
        for (Force f : Const.theWall) {
            if(cI.box.isContact(cI.pos, cI.ang, f, 7)){
                System.out.println("Dead");
                cI.isDead = true;
                flags.resetNum();
                cI.score = 0;
                return;
            }
        }
        
        flags.checkHit(cI.pos, cI.box, cI.ang);
    }

    public void reset(){
        cI.isDead = false;
        cI.pos = new Force(cIS.pos.x, cIS.pos.y);
        
        cI.lastPos = new Force(cIS.pos.x, cIS.pos.y);
        cI.facingDir = new Force(cIS.facingDir.x, cIS.facingDir.y);
        cI.ang = Math.atan(cI.facingDir.y/cI.facingDir.x);
        cI.movingDir = new Force();
    }

    public void changeDir(){
        Force dif = cI.facingDir.tempSub(cI.movingDir.getNorm());
        Force realdif = cI.facingDir.tempSub(cI.movingDir);

        if(dif.getMag() > 0 && !ins.slide){
            cI.movingDir.add(dif);
        }
        else if(dif.getMag() > 0 && ins.slide){
            cI.movingDir.add(realdif.scl((1.0 * dif.getMag()) / (5.0 * cI.movingDir.getMag())));
            cI.movingDir.add(cI.facingDir.tempScl(((cI.maxSpeed/cI.speed)-1) * cI.speed * dif.getMag()));
        }
    }

    public void updateVel(){
        cI.vel = cI.pos.tempSub(cI.lastPos);
        cI.velMag = cI.vel.getMag();
        cI.lastPos = new Force(cI.pos.x, cI.pos.y);
    }

    public void setInputs(boolean[] newInputs){
        ins.setInputs(newInputs);
    }

    public void move(){
        boolean moved = false;
        if(ins.forward || ins.back){
            moved = true;
        }
        if(ins.forward){
            goForward();
        }
        if(ins.back){
            goBack();
        }
        if(ins.left){
            turnLeft();
        }
        if(ins.right){
            turnRight();
        }

        if(!moved){
            idle();
        }
        changeDir();
        checkWall();
        updateVel();

        cI.pos.add(cI.movingDir);
    }

    public void paint(Graphics g){
        double simpleVel = (int)(cI.velMag * 10) / 10.0;
        flags.paintCur(g);
        Graphics2D g2d=(Graphics2D)g;
        g2d.translate((int)cI.pos.x, (int)cI.pos.y);
        g2d.drawString(Double.toString(simpleVel), 10, 10);
        g2d.rotate(cI.ang);
        g2d.drawImage(img, -10, -7, 30, 15, null);
        g2d.rotate(-cI.ang);
        g2d.translate(-(int)cI.pos.x, -(int)cI.pos.y);
    }

    public KeyListener getKeys(){
        return k;
    }
}