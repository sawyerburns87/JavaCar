import java.util.ArrayList;
import java.awt.*;

public class AllFlags {
    ArrayList<Flag> allFlags = new ArrayList<Flag>();
    int curFlag = 0;

    AllFlags(ArrayList<Flag> flags){
        allFlags = flags;
    }

    Flag getCurFlag(){
        return allFlags.get(curFlag);
    }

    int getFlagIndex(){
        return curFlag;
    }

    int checkHit(Force pos, carBox box, double ang){
        Flag f = getCurFlag();
        for (Force a : f.getCollides()) {
            if(box.isContact(pos, ang, a, 1)){
                System.out.println("Check Point Aquired");
                incFlag();
                return f.getScore();
            }
        }
        return 0;
    }

    void incFlag(){
        curFlag++;
        if(curFlag >= allFlags.size()){
            curFlag = 0;
        }
    }

    void paintCur(Graphics g){
        getCurFlag().paint(g);
    }
    void paintAll(Graphics g){
        for (Flag f : allFlags) {
            f.paint(g);
        }
    }
    void resetNum(){
        curFlag = 0;
    }
}
